<?php
   include('session.php');
?>
 <html>
 <body bgcolor="#EEFDEF">
 <head>
 <style>
 table
 {
    border-style:solid;
    border-width:2px;
    border-color:pink;
    text-align: center;
 }
 margin-bottom: -8px;}
 h3 {text-align: center;}
 </style>

 <?php
  include("config.php");
  session_start();
  $date1 = $_GET["date1"];
  $date2 = $_GET["date2"];
  $name = $_GET["name"];
  $experimentName = $_GET["experimentName"];

  echo "<h1>Experiment Report</h1>";?>
  Report Duration: <?php echo "&nbsp&nbsp".$date1."&nbsp&nbsp"; ?>
  to<?php echo "&nbsp&nbsp".$date2."&nbsp&nbsp";?><br>
  User Name:<?php echo "&nbsp&nbsp". $name;?><br>
  Experiment Name:<?php echo "&nbsp&nbsp". $experimentName;?><br>

 <?php
  $con = mysql_connect("localhost","admin","Ad123$%^min");
   if (!$con)
   {
    die('Could not connect: ' . mysql_error());
   }
 
  mysql_select_db("TDHELCCS",$con);
   if($name ==$_GET["name"])
   {  
      
     $query = "select DISTINCT name, U.loginID from USER U, CONFIGURATION C, SHOT_LOG S where U.loginID = C.loginID and C.configurationID = S.configurationID and name='$name' and dateTime between '$date1' and '$date2';";
//echo $query;

     $result = mysql_query($query);
        
         while($row = mysql_fetch_assoc($result))
         {
             echo "<h3>Experiments performed by " . $row['name'] . " (" . $row['loginID'] . ")</h3>";
             //echo "<br>";
  
             $query2 = "select distinct experimentName from CONFIGURATION where loginID ='" .  $row['loginID'] . "'";
             //echo $query2 . "<br>";
             $result2 = mysql_query($query2);
             while($row2 = mysql_fetch_assoc($result2))
             {
                 echo "<h4>Experiment Title:"."&nbsp&nbsp" . $row2['experimentName'] . "</h4>";
                 if (strcmp($name,"(All experiments)") == 0)  // All experiments
		   {
			

                      $query3 = "select distinct dateTime " . 
			  "from SHOT_LOG S, CONFIGURATION C " . 
			  "where S.configurationId = C.configurationId " .
				  "and loginID = '" . $row['loginID'] . "'";
			//echo $query3 . "<br>";
		   }
		 
                  else
		   {
			$query3 = "select distinct dateTime " . 
					  "from SHOT_LOG S, CONFIGURATION C " . 
					  "where S.configurationId = C.configurationId " .
					  "and loginID = '" . $row['loginID'] . "' ". 
					  "and experimentName = '" . $experimentName . "'";
		   }


                  $count = 1;
                  $result3 = mysql_query($query3);
                    while($row3 = mysql_fetch_assoc($result3))
	            {
	                 echo "<b>Shot" .  $count . "</b> (" . $row3['dateTime'] . ")";
	                 echo "<b><br>Operation Mode:</b>";
                         $query4 = "select DISTINCT configurationString from SHOT_LOG S ,
                               CONFIGURATION C WHERE S.configurationId=C.configurationId 
                               and loginId='".$row['loginID'] ."'";
	                 $result4= mysql_query($query4);
            
                         while($row4 = mysql_fetch_assoc($result4))
	                   {
	                     echo " ".substr($row4['configurationString'],55) ;
	                   }
                         echo "<br>";
                         echo "<b><br>Configuration</b><br>";
            
        
                        $str = "Experiment 1|Stage-1|1|1.1|Stage-2|1|1.2|Stage-3|1|1.3";
                        $pieces = explode("|",$str);
	     
                        echo "<tr>";
	                echo "<td>" ."<b>Stage Name</b>"."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp".$pieces[1]."&nbsp&nbsp". $pieces[4]."&nbsp
                              ". $pieces[7]. "</td>";
	                echo "<br>";
	                echo "<td>" ."<b>Status</b>"
                         ."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                         ".$pieces[2]."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                         ".  $pieces[5]."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                         ".$pieces[8]. "</td>";
                        echo "<br>";
	                echo "<td>" ."<b>Set Voltage (kV)</b>"."&nbsp&nbsp".$pieces[3]."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                         ". $pieces[6]."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp". $pieces[9]. "</td>";
                        echo "<br>";

                        echo "</tr>";
                        echo "<br>";
                        echo "<b>Output</b>";
            
                        $query6 = "select stageName,pulsePeak,pulseWidth FROM SHOT_LOG where dateTime ='". $row3['dateTime']."'";
	                $result6= mysql_query($query6);
           
                        echo "<table border='1'>
                        <tr>
                        <th>Stage</th>
                        <th>Load</th>
                        <th>Pulse Peak (micro ampere )</th>
                        <th>Pulse Width (micro seconds )</th>
                        </tr>";
                        while($row6 = mysql_fetch_assoc($result6))
	                {
	                   echo "<tr>";
			
                           $stage = explode('/', $row6['stageName']);

                           echo "<td>" .$stage[0] ."</td>";
                           echo "<td>" .$stage[1] ."</td>";
                           echo "<td>" .$row6['pulsePeak'] . "</td>";
                           echo "<td>" .$row6['pulseWidth'] . "</td>";
                           echo "</tr>";
                        }
                        echo "</table>";   
                        $count++;
	                echo "<br>";
                   }
             }
       echo "<br>";
     }
  }


 else { 
   
$query = "select DISTINCT name, U.loginID from USER U, CONFIGURATION C, SHOT_LOG S where U.loginID = C.loginID and C.configurationID = S.configurationID and name='$name' and dateTime between '$date1' and '$date2';";
    $result = mysql_query($query);
   
        while($row = mysql_fetch_assoc($result))
        {
          echo "<h3>Experiments performed by " . $row['name'] . " (" . $row['loginID'] . ")</h3>";
          //echo "<br>";
          $query2 = "select distinct experimentName from CONFIGURATION where loginID ='" .  $row['loginID'] . "'";
          //echo $query2 . "<br>";
          $result2 = mysql_query($query2);

          while($row2 = mysql_fetch_assoc($result2))
          {
            echo "<h4>Experiment Title:"."&nbsp&nbsp". $row2['experimentName'] . "</h4>";
		//echo "<br>";
	    if (strcmp($name,"(All experiments)") == 0)  // All experiments
		{	
                  $query3 = "select distinct dateTime " . 
		  "from SHOT_LOG S, CONFIGURATION C " . 
		  "where S.configurationId = C.configurationId " .
	          "and loginId = '" . $row['loginID'] . "'";
		//echo $query3 . "<br>";	
                }
            else
		{
			$query3 = "select distinct dateTime " . 
					  "from SHOT_LOG S, CONFIGURATION C " . 
					  "where S.configurationId = C.configurationId " .
					  "and loginId = '" . $row['loginID'] . "' ". 
					  "and experimentName = '" . $experimentName . "'";
		}

           $count = 1;
           $result3 = mysql_query($query3);
           while($row3 = mysql_fetch_assoc($result3))
	   {
	     echo "<b>Shot" .  $count . "</b> (" . $row3['dateTime'] . ")";
	     echo "<b><br>Operation Mode:</b>";
             $query4 = "select DISTINCT configurationString from SHOT_LOG S ,
                      CONFIGURATION C WHERE S.configurationId=C.configurationId 
                      and loginId='".$row['loginID'] ."'";
	     $result4= mysql_query($query4);
            
             while($row4 = mysql_fetch_assoc($result4))
	     {
	        echo " ".substr($row4['configurationString'],55) ;
	     }
           
             echo "<br>";
             echo "<b><br>Configuration</b><br>";
            
        
             $str = "Experiment 1|Stage-1|1|1.1|Stage-2|1|1.2|Stage-3|1|1.3";
             $pieces = explode("|",$str);
	     
             echo "<tr>";
	     echo "<td>" ."<b>Stage Name</b>"."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp".$pieces[1]."&nbsp&nbsp". $pieces[4]."&nbsp
                              ". $pieces[7]. "</td>";
	     echo "<br>";
	     echo "<td>" ."<b>Status</b>"
                         ."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                         ".$pieces[2]."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                         ".  $pieces[5]."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                         ".$pieces[8]. "</td>";
             echo "<br>";
	     echo "<td>" ."<b>Set Voltage (kV)</b>"."&nbsp".$pieces[3]."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                         ". $pieces[6]."&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp". $pieces[9]. "</td>";
             echo "<br>";

             echo "</tr>";

             echo "<br>";
             echo "<b>Output</b>";
            
             $query6 = "select stageName,pulsePeak,pulseWidth FROM SHOT_LOG where dateTime ='". $row3['dateTime']."'";
	     $result6= mysql_query($query6);
           
           
             echo "<table border='1'>
             <tr>
             <th>Stage</th>
             <th>Load</th>
             <th>Pulse Peak (micro ampere )</th>
             <th>Pulse Width (micro seconds )</th>
             </tr>";
             while($row6 = mysql_fetch_assoc($result6))
	     {  
	       echo "<tr>";
             
                $stage = explode('/', $row6['stageName']);
               echo "<td>" .$stage[0] ."</td>";
               echo "<td>" .$stage[1] ."</td>";
               echo "<td>" .$row6['pulsePeak'] . "</td>";
               echo "<td>" .$row6['pulseWidth'] . "</td>";
               echo "</tr>";
            }
            echo "</table>";   
            $count++;
	    echo "<br>";
          }
       }
     echo "<br>";
    }
  } 
 

 mysql_close($con);
 ?>
<h2><a href = "logout.php">Sign Out</a></h2>
 </body>
 </html>

