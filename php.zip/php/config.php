<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'admin');
   define('DB_PASSWORD', 'Ad123$%^min');
   define('DB_DATABASE', 'TDHELCCS');
   $con = mysql_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD);
   if (!$con) {
     die('Could not connect: ' . mysql_error());
   }
   
   mysql_select_db("TDHELCCS", $con);      
?>