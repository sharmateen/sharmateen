<?php
   include('session.php');
?>
<html>
   
   <head>
   <style>
 h1
 {   margin-top:15%;
    text-align: center;
 }
 h2
 {   margin-left:10%;
     margin-top:10%;
    text-align: left;
 }
</style>
<title>WELCOME </title>
   </head>
   
   <body bgcolor="#EEFDEF">
      <h1>WELCOME TO REPORT GENERATION SOFTWARE<?php echo $login_session; ?></h1> 
      <h2><a href = "filter.php">NEXT-></a></h2>
   </body>
   
</html>
