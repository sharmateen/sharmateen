 <!DOCTYPE HTML>
 <html>  
 <body bgcolor="#EEFDEF">
 <head>
 <?php
    $con = mysql_connect("localhost","admin","Ad123$%^min");
    if (!$con)
    {
      die('Could not connect: ' . mysql_error());
    }

    mysql_select_db("TDHELCCS", $con);


   function getExperiments ($name)
   {
    
     $experiments=array(); 
     $result= mysql_query("select distinct experimentName from CONFIGURATION C,USER U Where C.loginId=U.loginId ");
     while($r= mysql_fetch_array($result))
     {        
        array_push($experiments,$r['experimentName']);
     }
    return $experiments;
   }
   $experiments = getExperiments($name);
   //print_r($experiments);
   
   function getUsers ()
   {   
     $users=array(); 
     $result= mysql_query("select distinct name from USER");
     while($r= mysql_fetch_array($result))
     {        
        array_push($users,$r['name']);
     }
     return $users;
   }

   $users=getUsers();
   
 ?>
 <style>
 button
 {
   width:5%;
   margin-bottom:15%;
   margin-left:65%;
   margin-right:20%;
   background:lightblue;
 }
 form
 {
   margin-top:15%;
   margin-left:28.5%;
 }
 h1
 {
   text-align: center;
 }
 </style>
 
 <?php echo "<h1>REPORT GENERATION SOFTWARE FOR </h1>";
       echo "<h1>EXPERIMENT DATA</h1>";
 ?>
 <form action="report.php" method="get">
 
 <?php echo "&nbsp&nbsp&nbsp";?>
 Report Duration :<?php echo "&nbsp&nbsp&nbsp&nbsp";?> <input type="date" name="date1">
 <?php echo "&nbsp&nbsp";?>
 to<?php echo "&nbsp&nbsp";?><input type="date" name="date2" ><br><br>
 <?php echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";?>
 User Name :<?php echo "&nbsp&nbsp&nbsp&nbsp&nbsp";?><select name ="name">
   <option value="">(All Users)</option>
     <option value="Rajesh Kumar Patidar"><?php echo $users[0]; ?></option>
      <option value="Yogesh Sahu"><?php echo $users[1]; ?></option><br><br>
      </select><br><br>
 Experiment Name :<?php echo "&nbsp&nbsp&nbsp&nbsp&nbsp";?><select name ="experimentName">
   <option value="">(All Experiments)</option>
     <option value="Experiment 1"><?php echo $experiments[0]?></option>
      <option value="Experiment 2"><?php echo $experiments[1]; ?></option><br><br>
      </select>
 <br><br><br>
 <?php     echo   "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";?>
 <input type="submit" name="insert" value="Submit">
 </form>


 </body>
 </html>
