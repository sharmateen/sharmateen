<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysql_real_escape_string($_POST['username']);
      $mypassword = mysql_real_escape_string($_POST['password']); 
      
      $sql = "SELECT id FROM admin WHERE username = '$myusername' and passcode = '$mypassword'";
	  	  
      $result = mysql_query($sql); 
	  
      $row = mysql_fetch_array($result);
      $active = $row['active'];
      
      $count = mysql_num_rows($result);	  
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         $_SESSION['login_user'] = $myusername;
         
         header("location: welcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<html>
   
   <head>
       
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            margin-top: 10%;
            background-color:#EEFDEF;
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
            margin-right: 10%;
         }
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         .box {
            
            border:#666666 solid 1px;
         }
         h1
         {
           text-align: center;  
                   
          }
      </style>
      <?php echo "<h1>REPORT GENERATION SOFTWARE FOR </h1>";
       echo "<h1>LARGE EXPERIMENTAL DATA</h1>";
       ?>
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>LOGIN</b></div>
				
            <div style = "margin:30px">
               
               <form action = "" method = "post">
                  <label>User Name  :</label><input type = "text" name = "username" class = "box"/><br /><br />
                  <label>Password  :</label><input type = "password" name = "password" class = "box" /><br/><br />
                  <input type = "submit" value = " Submit "/><br />
               </form>
               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
					
            </div>
				
         </div>
			
      </div>

   </body>
</html>
